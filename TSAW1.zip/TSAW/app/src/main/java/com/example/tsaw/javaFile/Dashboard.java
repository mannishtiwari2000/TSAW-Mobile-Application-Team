package com.example.tsaw.javaFile;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.tsaw.R;

public class Dashboard extends AppCompatActivity {
Button call,launch,feedback;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
    call=(Button)findViewById(R.id.Call_Customer);
    launch=(Button)findViewById(R.id.Lounch);
    feedback=(Button)findViewById(R.id.Feedback);
    feedback.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Toast.makeText(Dashboard.this,"Feedback submiting ",Toast.LENGTH_SHORT).show();
        }
    });

    call.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Toast.makeText(Dashboard.this,"Call connecting",Toast.LENGTH_SHORT).show();
        }
    });
    launch.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Toast.makeText(Dashboard.this,"Task launching on maps",Toast.LENGTH_SHORT).show();
        }
    });
    }

}