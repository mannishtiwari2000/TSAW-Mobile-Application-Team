package com.example.tsaw.javaFile;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.tsaw.R;
import com.google.gson.JsonObject;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

import okhttp3.WebSocketListener;

public class Home extends AppCompatActivity {

    private EditText Password, Email;
    private Button Register;
    private Button login;
    TextView forget;
    public String token;

    Dbhelper mydb;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        Email = findViewById(R.id.Email);
        Password = findViewById(R.id.Password);
        forget = (TextView) findViewById(R.id.forget_password);
        Register = (Button) findViewById(R.id.Register);
        login = (Button) findViewById(R.id.Login);
        mydb = new Dbhelper(this);


        Email.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
                if(Email.getText().toString().isEmpty()) {
                   Email.setError("enter email address");

                }else {
                    if (Email.getText().toString().trim().matches(emailPattern)) {
                   Toast.makeText(Home.this,"valid email address",Toast.LENGTH_SHORT).show();

                    } else {
                        Email.setError("Invalid email address");

                    }
                }
            }
        });
        Password.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(Password.getText().toString().isEmpty()) {
                    Password.setError("enter Password");
                }
            }
        });

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = Email.getText().toString().trim();
                String password = Password.getText().toString().trim();
                userlogin(email, password);
//                Toast.makeText(Home.this, "CLICK", Toast.LENGTH_LONG).show();


            }
        });

        Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Intent intent = new Intent(Home.this, com.example.tsaw.javaFile.Register.class);
                startActivity(intent);
            }
        });
        forget.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(Home.this, Forget_password.class);
                startActivity(intent);
            }
        });

    }

    private void userlogin(String email, String password) {
        final RequestQueue requestQueue = Volley.newRequestQueue(this);
        String url = "https://tsaw.tech/AppApi/Operator/login.php";
        HashMap<String, String> params = new HashMap<String, String>();
        params.put("email", email);
        params.put("password", password);



        JsonObjectRequest getRequest = new JsonObjectRequest(Request.Method.POST, url, new JSONObject(params),
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {

                        try {
                            token = response.getString("jwt");

                            boolean Data = mydb.InsertData(token);
                            if (Data==true)
                            {
                                Toast.makeText(Home.this,"Sucessfully",Toast.LENGTH_LONG).show();
                                Intent intent = new Intent(Home.this, Welcome.class);
                                startActivity(intent);
                            }
                            else {
                                Toast.makeText(Home.this,"Login Failed",Toast.LENGTH_LONG).show();
                            }



                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
//
//                        Toast.makeText(Home.this, response.toString(), Toast.LENGTH_LONG).show();
                    }


                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(Home.this, error.toString()
                                , Toast.LENGTH_SHORT).show();
                    }
                }
        );

// add it to the RequestQueue
        requestQueue.add(getRequest);
    }

}


