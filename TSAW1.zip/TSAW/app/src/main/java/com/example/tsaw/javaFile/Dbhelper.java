package com.example.tsaw.javaFile;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.annotation.Nullable;

public class Dbhelper extends SQLiteOpenHelper {
    public static  final  String Database_Name="TSAW_Login";
    public static  final String Table_Name="User_Login";
    public static  final String JWT_Token="JWT";
    public Dbhelper(Context context) {
        super(context, Database_Name, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("Create table "+ Table_Name +"(Token_Value Text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
db.execSQL("Drop table if Exists "+Table_Name);
    onCreate(db);
    }

    public boolean InsertData(String JWT_Token)
    {
        SQLiteDatabase DB= this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("Token_Value",JWT_Token);

        long result  = DB.insert(Table_Name,null,values);
        if (result==-1)
        {
            return false;
        }
        else
            return true;
    }

    public Cursor Getdata()
    {
    SQLiteDatabase DB = this.getWritableDatabase();
    Cursor cursor=DB.rawQuery("Select Token_Value from "+Table_Name,null);
    return cursor;
    }

//    public boolean Updatedata(String JWT_Token)
//    {
//        SQLiteDatabase DB = this.getWritableDatabase();
//        ContentValues c = new ContentValues();
//        c.put("Token_Value",JWT_Token);
//        DB.update(Table_Name,null,null,null);
//return true;
//    }
//    public boolean DeleteData(String JWT_Token)
//    {
//        SQLiteDatabase Db = this.getReadableDatabase();
//        Db.delete(Table_Name,JWT_Token,null);
//        return true;
//    }
}
