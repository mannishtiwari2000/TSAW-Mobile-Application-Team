package com.example.tsaw.javaFile;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.tsaw.R;

public class govt_id extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    String[] id_proof = {" Select Id Proof","Aadhaar Card", "Pan Card","Other"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_govt_id);
        Spinner spinner=(Spinner)findViewById(R.id.spinner);
        spinner.setOnItemSelectedListener(this);
        ArrayAdapter aa = new ArrayAdapter(this,android.R.layout.simple_spinner_item,id_proof);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(aa);
}

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String text = parent.getItemAtPosition(position).toString();
        if(text.equals("Aadhaar Card"))
        {
            Intent intent=new Intent(this, aadhar_card.class);
            startActivity(intent);
            Toast.makeText(parent.getContext(),text,Toast.LENGTH_SHORT).show();
        }
        else if(text.equals("Pan Card"))
        {
            Intent intent=new Intent(this, Pan_card.class);
            startActivity(intent);
            Toast.makeText(parent.getContext(),text,Toast.LENGTH_SHORT).show();
        }
        else
        {
            Toast.makeText(parent.getContext(),"Please select Id proof ",Toast.LENGTH_SHORT).show();
        }

        Toast.makeText(parent.getContext(),text,Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

}
