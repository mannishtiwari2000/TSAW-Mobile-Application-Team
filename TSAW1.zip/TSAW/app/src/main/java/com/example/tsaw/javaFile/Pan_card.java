package com.example.tsaw.javaFile;

import android.content.Intent;
import android.graphics.Bitmap;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.example.tsaw.R;

public class Pan_card extends AppCompatActivity {
ImageView pan_img;
Button pan_pic;
private static final int requestCode=100;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pan_card);
        pan_img=(ImageView)findViewById(R.id.Pan_card_image);
        pan_pic=(Button)findViewById(R.id.Pan_card);
        pan_pic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(intent,100);
            }
        });

       }

    protected void onActivityResult(int requestCode , int resultCode, @Nullable Intent data ) {
        if(requestCode==100) {
            Bitmap captureImage = (Bitmap) data.getExtras().get("data");
            //set the image on image view
            pan_img.setImageBitmap(captureImage);

        }
    }
}
