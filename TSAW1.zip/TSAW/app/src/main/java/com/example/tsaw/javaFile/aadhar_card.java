package com.example.tsaw.javaFile;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.example.tsaw.R;

import static com.example.tsaw.R.*;
import static com.example.tsaw.R.id.*;

public class aadhar_card extends AppCompatActivity {
Button front_pic;
Button back_pic;
ImageView front_img;
ImageView back_img;
private static final int requestCode=100;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(layout.activity_aadhar_card);
        front_img=(ImageView)findViewById(id.front_img);
        front_pic=(Button)findViewById(front);
        back_img=(ImageView)findViewById(id.back_img);
        back_pic=(Button)findViewById(back);


        front_pic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(intent,100);

            }


        });

        back_pic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(intent,100);

            }
        });
    }

    protected void onActivityResult(int requestCode , int resultCode, @Nullable Intent data ) {
        if(requestCode==100 ) {
            Bitmap captureImage = (Bitmap) data.getExtras().get("data");
            //set the image on image view
            back_img.setImageBitmap(captureImage);
        }
        else if( requestCode==100)
        {
            Bitmap captureImage = (Bitmap) data.getExtras().get("data");
            //set the image on image view
            front_img.setImageBitmap(captureImage);

        }

    }

}
